// Stub header for fcntl.h

#include <bits/fcntl.h>
